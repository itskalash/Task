
import React from 'react';
import { connect } from "react-redux";

import {
  GetUsers
} from "./app/redux/actions/taskAction";
 
 class App extends React.Component {

  constructor(props) {
      super(props);

      this.state = {
      }
  }

  componentDidMount() {
    // making all API calls and store in the redux-store
    this.props.GetUsers();
  }
  
  render() {
    console.log("this.props.tasksss ", this.props.Loading);
    return (
      <div>
      ...
      </div>
    );
  }
}

const mapStateToProps = state => ({
  Loading: state.task.loading
});

const mapDispacthToProps = dispatch => {
  return {
    GetUsers: () => dispatch(GetUsers())    
  };
  
};
export default connect(
  mapStateToProps,
  mapDispacthToProps
)(App);

import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <header>
       <span id="spann"> <a href="#home"/>Home</span>
        <span id="spann"><a href="#live"/>Live</span>
        <span id="spann"><a href="#explore"/>Explore</span>
        <span><a href="chat"/>Chat</span>
       <input id="spann" type="text" placeholder="search"/>
      </header>
      <div id="ssss">
      <div id="div2">
      loren ipsum
      </div>
      <div id="div1"></div>
     </div>
    </div>
  );
}
